from pathlib import Path
import math, json
import cadquery as cq
import ezdxf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
O=Path('/workspace/work/cat_house'); O.mkdir(exist_ok=True)
W=D=600; T=18; H=540; slope=(H-T)/(W/2); off=T*math.sqrt(1+slope*slope); ih=H-off; ix=(ih-T)/slope
L=math.hypot(300,522)
left=[(-300,18),(0,H),(0,ih),(-ix,18)]
right=[(-x,z) for x,z in left]
def prism(p,y,d):
    # XZ workplane normal points toward -Y
    return cq.Workplane('XZ',origin=(0,y,0)).polyline(p).close().extrude(d)
parts=[('Floor',cq.Workplane('XY').box(W,D,T,centered=(True,True,False))),('Roof_left',prism(left,300,600)),('Roof_right',prism(right,300,600))]
rear=prism([(-ix,18),(ix,18),(0,ih)],300,18)
hole=cq.Workplane('XZ',origin=(0,301,230)).circle(30).extrude(20)
parts.append(('Rear',rear.cut(hole)))
for x in [-250,250]:
 for y in [-250,250]: parts.append((f'Foot_{x}_{y}',cq.Workplane('XY',origin=(x,y,-20)).box(40,40,20,centered=(True,True,False))))
a=cq.Assembly(name='Tent_cat_house')
for n,p in parts:
 assert p.val().isValid(),n
 a.add(p,name=n,color=cq.Color(0.72,0.49,0.28))
a.save(str(O/'tent_cat_house.step'))
compound=cq.Compound.makeCompound([p.val() for _,p in parts])
assert abs(compound.BoundingBox().zlen-560)<1e-6
cq.exporters.export(compound,str(O/'tent_cat_house.stl'))
# Technical drawings: model space millimetres, separate layers and true geometry.
doc=ezdxf.new('R2010'); doc.units=4
for name,c in [('OUTLINE',7),('DIM',3),('NOTES',2),('HIDDEN',8)]: doc.layers.new(name,dxfattribs={'color':c})
ms=doc.modelspace()
font=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams['axes.unicode_minus']=False
fig,axs=plt.subplots(2,2,figsize=(16.54,11.69)); fig.patch.set_facecolor('#fcfbf7')
fig.suptitle('帐篷式实木猫窝  /  TENT CAT HOUSE',fontproperties=font,fontsize=22,y=.97)
def poly(ax,p,ox=0,oy=0,close=True,hidden=False):
 pts=[(x+ox,y+oy) for x,y in p]
 ms.add_lwpolyline(pts,close=close,dxfattribs={'layer':'HIDDEN' if hidden else 'OUTLINE'})
 pp=p+[p[0]] if close else p
 ax.plot([x for x,y in pp],[y for x,y in pp],color='#374c4b',lw=1.4,ls='--' if hidden else '-')
def txt(ax,x,y,s,size=10,ox=0,oy=0):
 ax.text(x,y,s,fontproperties=font,fontsize=size,color='#253a38')
 ms.add_text(s,dxfattribs={'height':12,'insert':(x+ox,y+oy),'layer':'NOTES'})
def dim(ax,a,b,label,ox=0,oy=0):
 ax.annotate('',b,a,arrowprops={'arrowstyle':'<->','color':'#8c6543','lw':.9})
 mid=((a[0]+b[0])/2,(a[1]+b[1])/2)
 ax.text(mid[0]+8,mid[1]+9,label,fontsize=9,color='#8c6543')
 ms.add_linear_dim(base=(a[0]+ox,a[1]+oy),p1=(a[0]+ox,a[1]+oy),p2=(b[0]+ox,b[1]+oy),angle=90 if a[0]==b[0] else 0,dimstyle='EZDXF',dxfattribs={'layer':'DIM'}).render()
for ax in axs.flat: ax.set_aspect('equal');ax.axis('off')
ax=axs[0,0]
poly(ax,[(-300,0),(300,0),(300,18),(-300,18)])
poly(ax,left);poly(ax,right)
for x in [-250,250]: poly(ax,[(x-20,-20),(x+20,-20),(x+20,0),(x-20,0)])
dim(ax,(-300,-65),(300,-65),'600');dim(ax,(-365,-20),(-365,540),'560')
txt(ax,-300,595,'01  正视图 · 前部完全开放',13)
txt(ax,-280,120,f'入口底宽 {2*ix:.1f} / 净高 {ih-18:.1f}',9)
ax.set_xlim(-440,380);ax.set_ylim(-100,640)
ax=axs[0,1]; ox=900
poly(ax,[(-300,18),(300,18),(300,540),(-300,540)],ox)
poly(ax,[(-300,0),(300,0),(300,18),(-300,18)],ox)
poly(ax,[(282,18),(300,18),(300,ih),(282,ih)],ox,hidden=True)
for x in [-250,250]:poly(ax,[(x-20,-20),(x+20,-20),(x+20,0),(x-20,0)],ox)
dim(ax,(-300,-65),(300,-65),'600',ox); txt(ax,-300,595,'02  右视图',13,ox=ox)
ax.set_xlim(-440,380);ax.set_ylim(-100,640)
ax=axs[1,0];oy=-900
poly(ax,[(-300,-300),(300,-300),(300,300),(-300,300)],oy=oy)
poly(ax,[(0,-300),(0,300)],oy=oy,close=False)
poly(ax,[(-ix,282),(ix,282)],oy=oy,close=False,hidden=True)
dim(ax,(-300,-345),(300,-345),'600',oy=oy)
txt(ax,-300,355,'03  俯视图',13,oy=oy); txt(ax,30,0,'屋脊',10,oy=oy)
ax.set_xlim(-440,380);ax.set_ylim(-390,400)
ax=axs[1,1];ax.set_aspect('auto');ax.set_xlim(0,1);ax.set_ylim(0,1)
notes=[('04  板件与装配说明',14),('单位 mm；方案图 Rev A；尺寸为成品尺寸',10),('底板：600 × 600 × 18，1 件',11),(f'屋面板：外表面斜长 {L:.2f} × 600 × 18，2 件',11),(f'后板：底宽 {2*ix:.2f} × 高 {ih-18:.2f} × 18，1 件',11),('后板透气孔：Ø60，中心距底板下表面 230',10),('脚块：40 × 40 × 20，4 件；中心距两邻边各 50',10),(f'屋面与水平夹角 {math.degrees(math.atan(slope)):.2f}°',10),('屋脊接缝竖直、下口水平；锯切截面见 DXF 详图',10),('材质：18 mm 实木拼板；屋面木纹沿斜坡方向',10),('建议软垫 450 × 520 × 30，可拆洗（不计入木件）',10),('试装后定位预钻孔；暗藏角码连接屋脊、底板和后板',10),('金属连接件规格及孔位由木工按实材复核后确定',10),('入口边缘倒圆 R3；表面打磨，涂层固化后使用',10),('实木宽板需预留伸缩：后板配合留 1–2 mm 余量',10),('本版为结构方案，未含五金施工孔及承载验证',10)]
for i,(s,size) in enumerate(notes):
 y=.96-i*.061;ax.text(0,y,s,fontproperties=font,fontsize=size,color='#253a38')
 ms.add_text(s,dxfattribs={'height':13,'insert':(520,-520-i*35),'layer':'NOTES'})
# Roof cross section at 1:1, rear profile and circle
ms.add_lwpolyline([(x+1800,z) for x,z in left],close=True,dxfattribs={'layer':'OUTLINE'})
ms.add_text('ROOF SECTION 1:1 / XZ / 2 PCS MIRRORED',dxfattribs={'insert':(1480,590),'height':15,'layer':'NOTES'})
ms.add_lwpolyline([(x+1800,z-900) for x,z in [(-ix,18),(ix,18),(0,ih)]],close=True)
ms.add_circle((1800,230-900),30)
ms.add_text('REAR PANEL 1:1 / 18 THICK / VENT DIA 60',dxfattribs={'insert':(1480,-330),'height':15,'layer':'NOTES'})
doc.set_modelspace_vport(2200,center=(900,0));doc.saveas(O/'tent_cat_house.dxf')
fig.subplots_adjust(left=.05,right=.96,bottom=.04,top=.90,hspace=.15,wspace=.16)
fig.savefig(O/'drawing.pdf');fig.savefig(O/'drawing.png',dpi=140);plt.close(fig)
# Render actual STEP solids via triangle meshes.
fig=plt.figure(figsize=(11,9),facecolor='#f6f2e9');ax=fig.add_subplot(projection='3d',computed_zorder=True)
all_faces=[]; all_colors=[]
for name,p in parts:
 vertices,tris=p.val().tessellate(1)
 faces=[[(vertices[i].x,vertices[i].y,vertices[i].z) for i in tri] for tri in tris]
 all_faces.extend(faces); all_colors.extend(['#c99459' if 'Roof' in name else '#b47f48']*len(faces))
# cushion represented separately, illustrative
pad=cq.Workplane('XY',origin=(0,-15,18)).box(450,520,30,centered=(True,True,False)).edges('|Z').fillet(22)
v,t=pad.val().tessellate(2)
all_faces.extend([[(v[i].x,v[i].y,v[i].z) for i in tri] for tri in t]); all_colors.extend(['#e5e0cd']*len(t))
ax.add_collection3d(Poly3DCollection(all_faces,facecolors=all_colors,edgecolor='#80623e',linewidth=.15,alpha=.22))
ax.set_xlim(-340,340);ax.set_ylim(-340,340);ax.set_zlim(-20,600);ax.set_box_aspect((1,1,.9));ax.view_init(elev=22,azim=-58);ax.set_axis_off()
fig.text(.07,.91,'帐篷式实木猫窝',fontproperties=font,fontsize=25,color='#354a43')
fig.text(.07,.86,'600 × 600 × 560 mm  |  18 mm 实木拼板',fontproperties=font,fontsize=12,color='#76634d')
fig.text(.07,.06,'CAD 透视结构预览 · 软垫为示意 · 五金未建模',fontproperties=font,fontsize=10,color='#76634d')
fig.savefig(O/'preview.png',dpi=150,bbox_inches='tight');plt.close(fig)
# Verify reimport and drafting audit
re=cq.importers.importStep(str(O/'tent_cat_house.step'))
assert len(re.solids().vals())==8
assert not ezdxf.readfile(O/'tent_cat_house.dxf').audit().has_errors
(O/'README.txt').write_text('帐篷式实木猫窝，Rev A\n单位：mm。外形600宽×600深×560高，含20高脚块。\nSTEP：8个独立木件，可用FreeCAD/主流CAD打开。STL仅供形体预览。\nDXF：毫米1:1模型空间，含三视图与屋面截面/后板轮廓。PDF供阅读。\n前部全开放，后板有直径60透气孔。18厚实木拼板，建议松木或橡胶木。\n屋面板两端需斜切，准确截面以DXF及STEP为准，不能按矩形直角板直接拼接。\n方案未包含五金孔位、实木伸缩槽或承载验证；加工前由木工复核连接方式、刀具和配合公差。\n屋脊/底板/后板用暗藏角码连接，预钻避免劈裂。可拆软垫不计入木料。\n',encoding='utf-8')
print(json.dumps({'solids':len(re.solids().vals()),'roof_outer_length':L,'inner_base':2*ix,'inner_height':ih-18,'output':str(O)},ensure_ascii=False))
